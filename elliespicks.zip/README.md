Ellie's Picks
=============

A personal blogging theme for Ghost. Created for http://www.elliespicks.com
